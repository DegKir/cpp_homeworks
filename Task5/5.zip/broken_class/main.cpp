#include"library.h"

int main()
{
    //Раскомментить не будет работать
    // also_not_work(); 
    return 0;
}