//Раскомментить не будет работать
// void not_work()
// {
//     int a = 1 + 2;
// }

void also_not_work();
