#include <iostream>
#include <vector>

using namespace std;

int main()
{
    size_t n;
    cout << "How many elements ?" << endl;
    cin >> n;
    vector<int> v(n);
    cout << "Please, enter elements" << endl;
    for (size_t i = 0; i < n; ++i)
        cin >> v[i];

    //Кажется здесь можно секономить ещё пару строк и не писать фигурные скобки вообще.
    for (size_t i = 0; i < n; ++i)
    {
        size_t j = i + 1;
        while (j--)
            if (v[j - 1] > v[j])
                swap(v[j - 1], v[j]);
    }

    for (int elem : v)
        cout << elem << " ";
}