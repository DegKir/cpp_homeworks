#include <iostream>
#include <vector>

using namespace std;

int main()
{
    size_t n, left, right, m;
    int key;
    bool founded = 0;

    cout << "How many keys ?" << endl;
    cin >> n;
    vector<int> v(n);
    cout << "Please, enter keys from lower to higher" << endl;
    for (size_t i = 0; i < n; ++i)
        cin >> v[i];
    cout << "What key do you want to find ? ";
    cin >> key;

    left = 0;
    right = n;
    //Собственно, сам поиск. Пока лево не заедет за право или пока не найдёт нужный объект
    while ((right >= left) && (!founded))
    {
        m = (right + left) / 2;
        if (key == v[m])
            founded = 1;
        if (key > v[m])
            left = m + 1;
        else
            right = m - 1;
    }

    if (founded)
        cout << "FOUND!!!!";
    if (!founded)
        cout << "NOT FOUND !!!!!";
    return 0;
}