#include <iostream>
#include <vector>
#include <string.h>
#include <algorithm>

using namespace std;

int main()
{
    string a = "13a414";
    string b = "13a14";

    cout << "Hello there !" << endl
         << "Give me two string and i will return you their longest common subsequence " << endl;
    cout << "First string: ";
    cin >> a;
    cout << "Second string: ";
    cin >> b;

    const int asize = a.size();
    const int bsize = b.size();
    vector<char> com_sub(max(asize, bsize)); //Итоговая строчка

    //ABStract_Matrix - основная матрица в которую будут записаны длинны различных подпосл.
    //Инициализируется нулями ( узнал умное слово конструктор )
    vector<vector<int>> ABS_Matrix(asize + 1, vector<int>(bsize + 1, 0));

    for (int i = 1; i < asize + 1; ++i)
    {
        for (int j = 1; j < bsize + 1; ++j)
        {
            if (a[i - 1] == b[j - 1])
                ABS_Matrix[i][j] = ABS_Matrix[i - 1][j - 1] + 1;
            else
                ABS_Matrix[i][j] = max(ABS_Matrix[i - 1][j], ABS_Matrix[i][j - 1]);
        }
    }

    int j = bsize - 1;
    int i = asize - 1;

    while ((j >= 0) && (i >= 0))
    {
        if (a[i] != b[j])
        {
            if (ABS_Matrix[i - 1][j] < ABS_Matrix[i][j])
                j--;
            else
                i--;
        }
        else
        {
            com_sub.push_back(a[i]);
            j--;
            i--;
        }
    }

    reverse(com_sub.begin(), com_sub.end());

    cout << "I have found the longest common subsequence !" << endl<< "THERE IT IS : ";
    for (int i = 0; i <= com_sub.size(); ++i)
        cout << (char)com_sub[i];
    return 0;
}