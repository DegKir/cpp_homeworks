Задачи в порядке из задания :
    Koulun
    SGSE
    kvadr
    Exchange
Ответы на вопросы в файле Answers.txt