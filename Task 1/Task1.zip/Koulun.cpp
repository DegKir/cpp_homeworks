#include <iostream>
#include <iomanip>
//Задача про планету Коулун и перевод цен
using namespace std;

int main()
{
    char name[10] = "none";
    bool b_cashback = 0;
    char st_price[] = "Price";
    char st_cash_back[] = "Has_cash_back";
    char st_max_temp[] = "Max temperature";

    int price = -1;
    int temperature = -1;
    int wideness = 35;

    cout << "Product's name: ";
    cin >> name;
    cout << "\nProduct's price: ";
    cin >> price;
    cout << "\nIs cash-back availavle for this product? (true/false): ";
    cin >> boolalpha >> b_cashback;
    cout << "\nMaximum storing temperature : ";
    cin >> temperature;
    cout.fill('.');
    cout << endl
         << name << endl;
    cout << st_price << setw(wideness - sizeof(st_price) - 8) << '.' << setfill('0') << setw(8) << hex << uppercase << price << dec << endl;
    cout.fill('.');
    cout << st_cash_back << setw(wideness - sizeof(st_cash_back)) << boolalpha << b_cashback << endl;
    cout << st_max_temp << setw(wideness - sizeof(st_max_temp)) << showpos << temperature << endl;
    cin >> name;
    return 0;
}
