#include<iostream>
#include<vector>
#include<string>
#include<cmath>
using namespace std;
#include "Figure.h"

int main()
{
    tell_me();
    return 0;
}
